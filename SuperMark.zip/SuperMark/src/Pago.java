import java.util.Random;

public abstract class Pago {
	protected String Nombre_Apellido;
    protected long dni;
    protected long Numero_Tarjeta;
    protected int numeroPin;
    
    public Pago(String nombre, long dni, long Numero_Tarjeta, int pin) {
    	Nombre_Apellido= nombre;
    	this.dni= dni;
    	this.Numero_Tarjeta= Numero_Tarjeta;
    	this.numeroPin=pin;
    }
    
    public void SalidaPago() {
    	
    }
    public  boolean getBoolean() {
        Random random = new Random();
	        return random.nextBoolean();
		    }
    
    

}
