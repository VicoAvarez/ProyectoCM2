import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.cj.xdevapi.Statement;
public class CRUD_BaseDeDatos {
	private String JDBC_DRIVER;
	private String Identificacion;
	private String Contraseña;
	private Connection conector;
	private Statement lkl;
	
	public CRUD_BaseDeDatos(String jDBC_DRIVER, String identificacion, String contraseña) {
		super();
		JDBC_DRIVER = jDBC_DRIVER;
		Identificacion = identificacion;
		Contraseña = contraseña;
		conector=null;
		
		
	}


	public void setJDBC_DRIVER(String jDBC_DRIVER) {
		JDBC_DRIVER = jDBC_DRIVER;
	}


	public void setIdentificacion(String identificacion) {
		Identificacion = identificacion;
	}


	public void setContraseña(String contraseña) {
		Contraseña = contraseña;
	}


	public String getJDBC_DRIVER() {
		return JDBC_DRIVER;
	}


	public String getIdentificacion() {
		return Identificacion;
	}


	public String getContraseña() {
		return Contraseña;
	}

	@SuppressWarnings("rawtypes")
	public boolean conectar() {
		boolean rta=true;
		
		try {
			Class.forName(this.JDBC_DRIVER);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			conector=DriverManager.getConector(Identificacion,Contraseña);
			this.lkl= (Statement) conector.createStatement();
		} catch (SQLException e) {
			System.out.println("Error!!!" + e);
			rta=false;
		}
		
		return rta;
	}
	
	public Connection  getConector() {
		return conector;
	}
	
	

}
