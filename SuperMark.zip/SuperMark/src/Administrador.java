import java.util.Scanner;

public class Administrador {
	
	private String CodigoDeAcceso="465uSuperM";
	
	Administrador(){
		
	}
	
	public void Ingresar(String codigo) {
		Scanner in= new Scanner(System.in);
		if(CodigoDeAcceso== codigo) {
			System.out.println("BIENVENIDO");
			int opc= menu();
		do {
			System.out.println("Seleccione una accion ");
			int i= menu();
			switch(i) {
			case 1:
				System.out.println("Ingresando nuevo Producto");
				System.out.println("Codigo de Barra: ");
				System.out.println("Nombre: ");
				System.out.println("Marca ");
				System.out.println("Precio Unitario: ");
				System.out.println("Stock: ");
				break;
			case 2:
				System.out.println("Que desea Actualizar: ");
				switch(menuProducto()) {
				   case 1: 
					  break;
				   case 2:
					   break;
				   default:
					   System.out.println("Usted esta saliendo del Modo Actualizacion de Productos");
				} 
				break;
			case 3:
				System.out.println("Ingrese el Codigo de Barra");
				
				System.out.println("Se elimino el producto");
				break;
			default:
				System.out.println("Usted esta saliendo del Modo Administrador");
			}
		}while (opc==0 || opc==1 ||opc==2 || opc==3);
			
		}else {
			System.out.println("ERROR. Los datos ingresados son Incorrectos");
			System.out.println("Intentelo nuevamente o Comuniquese con el Administrador del Servidor");
		}
	}
	private int menu() {
		Scanner opc= new Scanner(System.in);
		System.out.println("1. Agregar Producto");
		System.out.println("2. Actualizar Producto");
		System.out.println("3. Eliminar Producto");
		System.out.println("0. Salir");
		System.out.print("Ingrese una opcion:");
		return opc.nextInt();
	}
	
	private int menuProducto() {
		Scanner opc= new Scanner(System.in);
		System.out.println("1. Actualizar Precio ");
		System.out.println("2. Actualizar Stock ");
		System.out.println("0. Salir");
		System.out.print("Ingrese una opcion:");
		return opc.nextInt();
	}
	

}
