
import java.util.Scanner;

public class SuperMercado {
	private Carrito carrito; 
	private User usuario;
	
	public void Menu() {
		Scanner in = new Scanner(System.in);
		
	System.out.println("****............BIENVENIDOS................*****");
	System.out.println("****...Menu(1):Ingresar a su Cuenta - (2): Crear Cuenta - (3)Administrar......****");
	
	System.out.println("************************************************************");
    
	int  menu= in.nextInt();
	User usuario= new User();
	switch (menu) {
	case 1:
		  usuario.ingresar(in.nextLine(), in.nextLine()); 
          break;			
	case 2:
		System.out.println("Iniciando Registro");  
	    usuario.registrarse();
	case 3:
		
		Administrador adminis= new Administrador();
		System.out.println("Coloque el Codigo de Administracion"); 
		adminis.Ingresar(in.nextLine());
	break;
	default:
		System.out.println("Usted esta saliendo de SuperMark...");
		
	}
}}