import java.util.Scanner;

public class User {

    
    public void ingresar(String email, String contraseña) {
    	// Buscar
    	
    	
    }
    
    public void registrarse() {
    	// email
    	//Contraseña
    	// Nombre y Apellido
    	
    }
    
    private int menu() {
    	System.out.println("---------------------------------");
		System.out.println("1. Ver Usuario");
		System.out.println("2. Ver Carrito");
		System.out.println("3. Comprar");
		System.out.println("0. Salir");
		Scanner in= new Scanner(System.in);
		return in.nextInt();
    }


}
