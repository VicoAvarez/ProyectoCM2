
public class TarjetaCredito extends Pago{
    private int cuotas; 
	public TarjetaCredito(String nombre, long dni, long Numero_Tarjeta, int pin, int cuotas) {
		super(nombre, dni, Numero_Tarjeta, pin);
		// TODO Auto-generated constructor stub
		this.cuotas= cuotas;
	}
	
	  
    public void SalidaPago() {
    	if(getBoolean()) {
    		System.out.println("Se realizo el pago con exito");
    		System.out.println("Se cobrara  en " + cuotas + "cuotas");
    	}else{
    		System.out.println("Se llego al limite de su tarjeta");
    	}
    	
    	
    }
	

}
