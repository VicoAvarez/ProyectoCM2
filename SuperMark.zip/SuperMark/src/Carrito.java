

public class Carrito {
    
     private Producto[] ListProductos;
     private static int  indice =0;
     
     public void pagar() {
    	 
     }
     
     public void Agregar_Carrito(Producto producto) {
    	 if(indice<30 && indice>=0) {
    		 ListProductos[indice]=producto;
    	     indice++; 
    	     System.out.println("Se agrego un nuevo producto a su carrito");
    	 }
    	 else {
    		 System.out.println("Su carrito esta lleno");
    	 }
    	
     }
     public void Quitar_Carrito(Producto producto) {
    	 int b=0, in=0;
    	 
    	 while(in<indice && b==0) {
    			 if(producto!=ListProductos[in]) {
    				 b=1;
    			 }else {
    				 in++;
    			 }
    	 }
    	 if(b==1) {
    		 for(int i=in; i<indice; i++) {
    			 ListProductos[i]= ListProductos[i+1];
    		 }
    		 indice--;
    		 System.out.println("El producto fue eliminado del carrito");
    	 }else {
    		 System.out.println("No se encontro el producto");
    	 }
    	
     }
     public double Total_Carrito() {
    	 double total=0;
    	 for(int i=0; i<indice;i++) {
    		 total+=ListProductos[i].getPrecio();
    	 }
    	 return total;
     }
     
     
     
     
}
