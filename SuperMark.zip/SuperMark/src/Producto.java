
public class Producto {
	private String nombre;
	private String marca;
	private double precio;

	
	
	public void IngresarProducto() {
		
	}
	public double getPrecio() {
		return precio;
	}
	public void setProductoStockSumar(int cantidad) {
		//stock+=cantidad;
	}
    public void setProductoStockRestar(int cantidad) {
		//stock-=cantidad;
	}
	public void setProductoPrecio(double precio) {
		this.precio=precio;
	}

}
