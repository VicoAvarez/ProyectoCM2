import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.cj.xdevapi.Statement;

public class Conexion_BaseDeDatos {
	private String Drive;
	private String Url;
	private String Usuario;
	private String Contraseña;
	private Connection Connec;
	private Statement Stmt;
	private ResultSet Rs;
	
	
	
	public String getDrive() {
		return Drive;
	}



	public void setDrive(String drive) {
		Drive = drive;
	}



	public String getUrl() {
		return Url;
	}



	public void setUrl(String url) {
		Url = url;
	}



	public String getUsuario() {
		return Usuario;
	}



	public void setUsuario(String usuario) {
		Usuario = usuario;
	}



	public String getContraseña() {
		return Contraseña;
	}



	public void setContraseña(String contraseña) {
		Contraseña = contraseña;
	}



	public Connection getConnec() {
		return Connec;
	}



	public void setConnec(Connection connec) {
		Connec = connec;
	}



	public Statement getStmt() {
		return Stmt;
	}



	public void setStmt(Statement stmt) {
		Stmt = stmt;
	}



	public ResultSet getRs() {
		return Rs;
	}



	public void setRs(ResultSet rs) {
		Rs = rs;
	}



	public Conexion_BaseDeDatos  (String jDBC_DRIVER, String dB_URL, String uSER, String pASS) {
		super();
		Drive = jDBC_DRIVER;
	    Url = dB_URL;
		Usuario = uSER;
		Contraseña = pASS;
		Connec=null;
		Stmt=null;
		Rs=null;
	}
	
	
	
	public void Conectar() {
		try {
			Class.forName(Drive);
			System.out.println("Conectando con el Servidor ");
			Connec=DriverManager.getConnection(Url,Usuario,Contraseña);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	@SuppressWarnings("rawtypes")
	public void CerrarConexion() {
		try {
			Stmt=(Statement) Connec.createStatement();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if(Stmt!=null) {
				((Connection) Stmt).close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			if(Rs!=null) {
				Rs.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	
	public ResultSet ConsultarMet(String consulta) {
		try {
			Stmt=(Statement) Connec.createStatement();
			
			Rs=((java.sql.Statement) Stmt).executeQuery(consulta);
			return Rs;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}
	
	
	public void RealizarCambios(String sql) {
		try {
			System.out.println("Actualizando Base");
			Stmt=(Statement) Connec.createStatement();
			((java.sql.Statement) Stmt).executeUpdate(sql);
			System.out.println("Base actualizada");
		} catch (Exception e) {
			e.printStackTrace();		
		}
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Conexion_BaseDeDatos conex=new Conexion_BaseDeDatos("com.mysql.cj.jdbc.Driver","jdbc:mysql://localhost:3306/Usuario_Producto","root","1905");
		ResultSet registros=conex.ConsultarMet("Select;");
		
		try {
			while(registros.next()) {
				String nombre=registros.getString("Nombre");
				String Apellido=registros.getString("Apellido");
				int dni= registros.getInt("Dni");
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		conex.CerrarConexion();
		
		
	}
}
