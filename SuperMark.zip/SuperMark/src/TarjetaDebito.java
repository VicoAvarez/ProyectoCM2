
public class TarjetaDebito extends Pago{

	public TarjetaDebito(String nombre, long dni, long Numero_Tarjeta, int pin) {
		super(nombre, dni, Numero_Tarjeta, pin);
		// TODO Auto-generated constructor stub
	}
	
	 public void SalidaPago() {
		 if(getBoolean()) {
			System.out.println("Se realizo el pago con exito"); 
		 }
		 else {
			 System.out.println("NO se puedo realizar el pago");
		 }
	    	
	    	
	    }
	
	    
	

}
